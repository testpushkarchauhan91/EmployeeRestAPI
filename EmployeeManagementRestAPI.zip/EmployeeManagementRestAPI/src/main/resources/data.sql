insert into Employee(fname,lname,salary,grade) values('Sachin','Tendulkar',5000.0,'A');
insert into Employee(fname,lname,salary,grade) values('Saurav','Ganguly',2000.0,'B');
insert into Employee(fname,lname,salary,grade) values('Rohit','Sharma',3000.0,'B');
insert into Employee(fname,lname,salary,grade) values('Kapil','Dev',2000.0,'C');
